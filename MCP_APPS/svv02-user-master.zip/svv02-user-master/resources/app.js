/* ══════════════════════════════════════════════
   app.js — Standard List Page UI  v3.1
   UI logic: render, filter, charts, CRUD, export.
   Depends on: config.js, api.js
   ══════════════════════════════════════════════ */

const PALETTE = ["#2563EB","#059669","#F59E0B","#7C3AED","#0891B2","#DC2626","#EC4899","#14B8A6"];

let allData      = [];
let activeFilter = "All";
let dropFilters  = {};   // { key: selectedValue }
let editIndex    = null;
let deleteIndex  = null;

/* ── Boot ─────────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  document.title = CONFIG.title;
  loadData();
});

/* ── Load data ────────────────────────────────────────────── */
async function loadData() {
  showLoading(true);
  hideError();
  try {
    allData = await apiList();
    renderHeader();
    renderStats();
    renderCharts();
    renderHead();
    renderFilters();
    applyFilters();
  } catch (e) {
    showError(e.message);
  }
  showLoading(false);
}

/* ── Loading / Error ──────────────────────────────────────── */
function showLoading(on) {
  const el = document.getElementById("loading");
  el.style.display = on ? "flex" : "none";
  el.style.opacity = on ? "1" : "0";
}
function showError(msg, code) {
  const box = document.getElementById("error-box");
  box.classList.add("show");
  document.getElementById("error-msg").textContent  = msg;
  document.getElementById("error-code").textContent = code ? "status: " + code : "";
}
function hideError() { document.getElementById("error-box").classList.remove("show"); }

/* ── Toast ────────────────────────────────────────────────── */
function toast(msg, cls) {
  const t = document.getElementById("toast");
  t.textContent = msg; t.className = cls || "";
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2400);
}

/* ── UUIDv7 ───────────────────────────────────────────────── */
function uuidv7() {
  const ts = Date.now().toString(16).padStart(12,"0");
  const rnd = () => Math.floor(Math.random()*16).toString(16);
  let s = ts+"7"; while(s.length<32) s+=rnd();
  return `${s.slice(0,8)}-${s.slice(8,12)}-${s.slice(12,16)}-${s.slice(16,20)}-${s.slice(20,32)}`;
}

/* ── Badge colour ─────────────────────────────────────────── */
function badgeColor(val, key) {
  if (CONFIG.badgeColors && CONFIG.badgeColors[val]) return CONFIG.badgeColors[val];
  const k    = key || (CONFIG.columns.find(c => c.type==="badge")||{}).key || CONFIG.filterKey;
  const vals = [...new Set(allData.map(r => r[k]))];
  return PALETTE[Math.max(vals.indexOf(val),0) % PALETTE.length];
}

/* ── Header ───────────────────────────────────────────────── */
function renderHeader() {
  const f = CONFIG.features;
  document.getElementById("page-title").textContent    = CONFIG.title;
  document.getElementById("page-subtitle").textContent = CONFIG.subtitle || "";
  if (CONFIG.icon) document.getElementById("header-icon").textContent = CONFIG.icon;
  document.getElementById("header-meta").innerHTML =
    `<span>Updated: ${new Date().toLocaleTimeString()}</span>`;
  document.getElementById("header-actions").innerHTML =
    f.refresh ? `<button class="btn-refresh" onclick="loadData()">⟳ Refresh</button>` : "";
  document.getElementById("app-header").style.display = "";

  const acts = [];
  if (f.export) acts.push(`<button class="btn btn-outline btn-sm" onclick="exportCSV()">⬇ Export CSV</button>`);
  if (f.create) acts.push(`<button class="btn btn-primary btn-sm" onclick="openCreate()">＋ New Record</button>`);
  document.getElementById("table-actions").innerHTML = acts.join("");
  document.getElementById("search-box").style.display = f.search ? "" : "none";
}

/* ── Stat cards ───────────────────────────────────────────── */
function renderStats() {
  const el = document.getElementById("stats");
  if (!CONFIG.stats || !CONFIG.stats.length) { el.innerHTML=""; return; }
  el.innerHTML = CONFIG.stats.map((s,i) => {
    const n = s.filter==="*"
      ? allData.length
      : allData.filter(r => String(r[CONFIG.filterKey])===s.filter).length;
    const col = PALETTE[i % PALETTE.length];
    return `<div class="stat-card" style="--accent:${col}">
      <div class="stat-label">${s.label}</div>
      <div class="stat-value">${n}</div>
    </div>`;
  }).join("");
}

/* ── Charts ───────────────────────────────────────────────── */
function renderCharts() {
  const ch = CONFIG.charts;
  if (!ch) return;
  document.getElementById("charts-row").style.display = "";

  // ── Bar chart (count by barKey) ─────────────────────────
  if (ch.bar) {
    const key    = ch.bar.key;
    const title  = ch.bar.label || key;
    const counts = {};
    allData.forEach(r => { const v=r[key]||"—"; counts[v]=(counts[v]||0)+1; });
    const labels = Object.keys(counts);
    const vals   = Object.values(counts);
    const maxV   = Math.max(...vals,1);

    document.getElementById("bar-chart-title").textContent = title;
    const bars = labels.map((lbl,i) => {
      const col = PALETTE[i % PALETTE.length];
      const h   = Math.round((vals[i]/maxV)*110);
      return `<div class="bar-wrap">
        <div class="bar-val">${vals[i]}</div>
        <div class="bar" style="height:${h}px;background:${col}" title="${lbl}: ${vals[i]}"></div>
        <div class="bar-label" title="${lbl}">${lbl}</div>
      </div>`;
    }).join("");
    document.getElementById("bar-chart-wrap").innerHTML =
      `<div class="bar-chart">${bars}</div>`;
  }

  // ── Donut chart (count by donutKey) ────────────────────
  if (ch.donut) {
    const key    = ch.donut.key;
    const title  = ch.donut.label || key;
    const counts = {};
    allData.forEach(r => { const v=r[key]||"—"; counts[v]=(counts[v]||0)+1; });
    const labels = Object.keys(counts);
    const vals   = Object.values(counts);
    const total  = vals.reduce((a,b)=>a+b,0)||1;
    const colors = labels.map((_,i) => PALETTE[i % PALETTE.length]);

    document.getElementById("donut-chart-title").textContent = title;

    // Build SVG donut
    const cx=70, cy=70, r=54, hole=30;
    let angle = -Math.PI/2;
    let paths = "";
    vals.forEach((v,i) => {
      const slice = (v/total)*Math.PI*2;
      const x1=cx+r*Math.cos(angle), y1=cy+r*Math.sin(angle);
      angle += slice;
      const x2=cx+r*Math.cos(angle), y2=cy+r*Math.sin(angle);
      const lf = slice>Math.PI?1:0;
      const xi1=cx+hole*Math.cos(angle-slice), yi1=cy+hole*Math.sin(angle-slice);
      const xi2=cx+hole*Math.cos(angle),       yi2=cy+hole*Math.sin(angle);
      paths += `<path d="M${x1} ${y1} A${r} ${r} 0 ${lf} 1 ${x2} ${y2}
        L${xi2} ${yi2} A${hole} ${hole} 0 ${lf} 0 ${xi1} ${yi1}Z"
        fill="${colors[i]}" stroke="#fff" stroke-width="2">
        <title>${labels[i]}: ${v}</title></path>`;
    });
    const legend = labels.map((lbl,i) =>
      `<div class="legend-item">
        <div class="legend-dot" style="background:${colors[i]}"></div>
        <span class="legend-label">${lbl}</span>
        <span class="legend-val">${vals[i]}</span>
      </div>`
    ).join("");

    document.getElementById("donut-chart-wrap").innerHTML =
      `<div class="donut-wrap">
        <svg class="donut-svg" width="140" height="140" viewBox="0 0 140 140">${paths}</svg>
        <div class="donut-legend">${legend}</div>
      </div>`;
  }
}

/* ── Table head ───────────────────────────────────────────── */
function renderHead() {
  const f = CONFIG.features;
  let h = CONFIG.columns.map(c=>`<th>${c.label}</th>`).join("");
  if (f.edit||f.delete) h+=`<th class="actions-col">Actions</th>`;
  document.getElementById("thead-row").innerHTML = h;
  document.getElementById("table-title").textContent = CONFIG.title;
}

/* ── Filters: dropdowns or pills ─────────────────────────── */
function renderFilters() {
  const dd = CONFIG.filterDropdowns;

  if (dd && dd.length) {
    // ── Dropdown mode ──────────────────────────────────────
    // init dropFilters state
    dd.forEach(d => { if (!(d.key in dropFilters)) dropFilters[d.key]=""; });

    document.getElementById("pills").style.display = "none";
    const wrap = document.getElementById("filter-dropdowns");
    wrap.innerHTML = dd.map(d => {
      const vals = [...new Set(allData.map(r=>r[d.key]).filter(v=>v!=null))].sort();
      const opts = [`<option value="">All ${d.label}</option>`,
        ...vals.map(v=>`<option value="${v}" ${dropFilters[d.key]===v?"selected":""}>${v}</option>`)
      ].join("");
      return `<div class="filter-group">
        <label>${d.label}</label>
        <select onchange="setDropFilter('${d.key}',this.value)">${opts}</select>
      </div>`;
    }).join("");

  } else if (CONFIG.filterKey) {
    // ── Pills mode (legacy) ────────────────────────────────
    document.getElementById("filter-dropdowns").innerHTML = "";
    const el = document.getElementById("pills");
    el.style.display = "";
    const vals = ["All",...new Set(allData.map(r=>r[CONFIG.filterKey]).filter(v=>v!=null))];
    el.innerHTML = vals.map(v => {
      const bg = v==="All"?"":` --pill-bg:${badgeColor(v)};`;
      return `<button class="pill ${v===activeFilter?"active":""}" style="${bg}"
        onclick="setFilter('${String(v).replace(/'/g,"\\'")}')">${v}</button>`;
    }).join("");
  }
}

function setFilter(v)          { activeFilter=v; renderFilters(); applyFilters(); }
function setDropFilter(key,v)  { dropFilters[key]=v; applyFilters(); }

/* ── Search + filter ──────────────────────────────────────── */
function applyFilters() {
  const q = (document.getElementById("search").value||"").toLowerCase();
  let rows = allData.map((r,i)=>({r,i}));

  // dropdown filters
  if (CONFIG.filterDropdowns) {
    CONFIG.filterDropdowns.forEach(d => {
      const sel = dropFilters[d.key]||"";
      if (sel) rows = rows.filter(x=>String(x.r[d.key])===sel);
    });
  } else if (CONFIG.filterKey && activeFilter!=="All") {
    rows = rows.filter(x=>String(x.r[CONFIG.filterKey])===activeFilter);
  }

  // search
  if (q && CONFIG.searchKeys.length)
    rows = rows.filter(x=>CONFIG.searchKeys.some(k=>String(x.r[k]??"").toLowerCase().includes(q)));

  document.getElementById("table-meta").textContent =
    `${rows.length} of ${allData.length} records`;
  renderTable(rows);
}

/* ── Cell renderer ────────────────────────────────────────── */
function cell(r,c) {
  const v = r[c.key];
  if (v==null||v==="") return `<td class="date">—</td>`;
  switch(c.type) {
    case "code":   return `<td class="code">${v}</td>`;
    case "number": return `<td class="num">${v}</td>`;
    case "date":   return `<td class="date">${String(v).slice(0,10)}</td>`;
    case "badge": {
      const col=badgeColor(v,c.key);
      return `<td><span class="badge" style="background:${col}1A;color:${col}">${v}</span></td>`;
    }
    case "status": {
      const on=["true","active","1","yes","y"].includes(String(v).toLowerCase());
      return on
        ?`<td><span class="dot dot-on"></span><span style="font-size:12px;color:var(--success);font-weight:600">Active</span></td>`
        :`<td><span class="dot dot-off"></span><span style="font-size:12px;color:var(--danger);font-weight:600">Inactive</span></td>`;
    }
    default: return `<td>${v}</td>`;
  }
}

/* ── Table body ───────────────────────────────────────────── */
function renderTable(rows) {
  const tbody   = document.getElementById("tbody");
  const f       = CONFIG.features;
  const colspan = CONFIG.columns.length+((f.edit||f.delete)?1:0);
  if (!rows.length) {
    tbody.innerHTML=`<tr><td colspan="${colspan}"><div class="empty">No records found</div></td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map(x=>{
    let tds = CONFIG.columns.map(c=>cell(x.r,c)).join("");
    if (f.edit||f.delete) {
      let acts="";
      if (f.edit)
        acts+=`<button class="icon-btn edit" title="Edit" onclick="openEdit(${x.i})">
          <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
          </svg></button>`;
      if (f.delete)
        acts+=`<button class="icon-btn del" title="Delete" onclick="openDelete(${x.i})">
          <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <polyline points="3 6 5 6 21 6"/>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
          </svg></button>`;
      tds+=`<td class="actions">${acts}</td>`;
    }
    return `<tr>${tds}</tr>`;
  }).join("");
}

/* ── CRUD: Create / Edit ──────────────────────────────────── */
function formCols() { return CONFIG.columns.filter(c=>c.editable!==false); }
function openCreate() { editIndex=null; openForm("New Record",{}); }
function openEdit(i)  { editIndex=i;   openForm("Edit Record",allData[i]); }

function openForm(title,rec) {
  document.getElementById("form-title").textContent = title;
  document.getElementById("form-fields").innerHTML  = formCols().map(c=>{
    const val=rec[c.key]??""; const req=c.required?'<span class="req"> *</span>':"";
    if (c.options) {
      const opts=c.options.map(o=>`<option value="${o}" ${String(val)===String(o)?"selected":""}>${o}</option>`).join("");
      return `<div class="field"><label>${c.label}${req}</label>
        <select id="fld-${c.key}"><option value="">— select —</option>${opts}</select></div>`;
    }
    const itype=c.type==="number"?"number":c.type==="date"?"date":"text";
    return `<div class="field"><label>${c.label}${req}</label>
      <input type="${itype}" id="fld-${c.key}" value="${String(val).replace(/"/g,"&quot;")}">
      ${c.type==="code"?'<div class="hint">code field</div>':""}</div>`;
  }).join("");
  document.getElementById("form-modal").classList.add("show");
}

async function saveForm() {
  const base=editIndex===null?{}:{...allData[editIndex]};
  for (const c of formCols()) {
    const v=document.getElementById("fld-"+c.key).value.trim();
    if (c.required&&!v){toast(c.label+" is required","err");return;}
    base[c.key]=v;
  }
  const btn=document.getElementById("form-save");
  btn.disabled=true;
  try {
    if (editIndex===null){ await apiCreate(base); toast("Record created","ok"); }
    else { await apiUpdate(base[CONFIG.idKey],base); toast("Record updated","ok"); }
    closeModal("form-modal"); await loadData();
  } catch(e){toast(e.message,"err");}
  btn.disabled=false;
}

/* ── CRUD: Delete ─────────────────────────────────────────── */
function openDelete(i) {
  deleteIndex=i;
  const r=allData[i];
  const label=CONFIG.searchKeys.map(k=>r[k]).filter(Boolean).join(" · ")||r[CONFIG.idKey]||"";
  document.getElementById("del-label").textContent=label;
  document.getElementById("del-modal").classList.add("show");
}
async function confirmDelete() {
  const btn=document.getElementById("del-confirm"); btn.disabled=true;
  try {
    await apiDelete(allData[deleteIndex][CONFIG.idKey]);
    toast("Record deleted","ok"); closeModal("del-modal"); await loadData();
  } catch(e){toast(e.message,"err");}
  btn.disabled=false;
}

function closeModal(id){document.getElementById(id).classList.remove("show");}

/* ── Export CSV ───────────────────────────────────────────── */
function exportCSV() {
  const cols=CONFIG.columns.map(c=>c.key);
  const esc=v=>`"${String(v??"").replace(/"/g,'""')}"`;
  const csv=[cols.join(","),...allData.map(r=>cols.map(c=>esc(r[c])).join(","))].join("\n");
  const a=document.createElement("a");
  a.href="data:text/csv;charset=utf-8,"+encodeURIComponent(csv);
  a.download=CONFIG.csvName; a.click();
}
