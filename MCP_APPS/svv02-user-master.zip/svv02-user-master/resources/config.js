/* ══════════════════════════════════════════════
   config.js — User Master
   Edit ONLY this file to customise the list page.
   ══════════════════════════════════════════════ */
const CONFIG = {
  title:    "User Master",
  subtitle: "get_svv02_user_master_01 · svv02_user_master_01",
  csvName:  "svv02-user-master.csv",
  icon:     "👤",

  /* Primary key */
  idKey: "psk_id",

  /* Feature toggles */
  features: {
    create:  true,
    edit:    true,
    delete:  true,
    search:  true,
    export:  true,
    refresh: true
  },

  columns: [
    { key: "psk_id",             label: "ID",               type: "number", editable: false },
    { key: "member_id",          label: "Member ID",        type: "text",   required: true  },
    { key: "member_type",        label: "Member Type",      type: "badge",  required: true, options: ["admin","user","staff","guest"] },
    { key: "firstname",          label: "First Name",       type: "text",   required: true  },
    { key: "middlename",         label: "Middle Name",      type: "text"                    },
    { key: "lastname",           label: "Last Name",        type: "text",   required: true  },
    { key: "username",           label: "Username",         type: "text",   required: true  },
    { key: "email",              label: "Email",            type: "text",   required: true  },
    { key: "mobile",             label: "Mobile",           type: "text",   required: true  },
    { key: "user_gender",        label: "Gender",           type: "badge",  options: ["Male","Female","Other"] },
    { key: "user_dob",           label: "Date of Birth",    type: "date"                    },
    { key: "user_marital_status",label: "Marital Status",   type: "badge",  options: ["Single","Married","Divorced","Widowed"] },
    { key: "user_marital_type",  label: "Marital Type",     type: "text"                    },
    { key: "user_spouse_name",   label: "Spouse Name",      type: "text"                    },
    { key: "user_father_name",   label: "Father Name",      type: "text"                    },
    { key: "user_address",       label: "Address",          type: "text"                    },
    { key: "user_bio",           label: "Bio",              type: "text"                    },
    { key: "user_intro",         label: "Intro",            type: "text"                    },
    { key: "user_kyc",           label: "KYC",              type: "status", options: ["true","false"] },
    { key: "user_profile",       label: "Profile URL",      type: "text"                    },
    { key: "registered_on",      label: "Registered On",    type: "date",   editable: false },
    { key: "expiry_date",        label: "Expiry Date",      type: "date"                    },
    { key: "auth_token",         label: "Auth Token",       type: "code"                    },
    { key: "password_hash",      label: "Password Hash",    type: "code"                    },
  ],

  searchKeys: ["firstname", "lastname", "username", "email", "mobile", "member_id"],

  filterKey: "member_type",

  stats: [
    { label: "Total Users",  filter: "*"     },
    { label: "Admin",        filter: "admin" },
    { label: "Staff",        filter: "staff" },
    { label: "Members",      filter: "user"  },
  ],

  badgeColors: {
    admin:   "#7C3AED",
    staff:   "#2563EB",
    user:    "#16A34A",
    guest:   "#D97706",
    Male:    "#3B82F6",
    Female:  "#EC4899",
    Other:   "#6B7280",
    Married: "#16A34A",
    Single:  "#F59E0B",
  },

  charts: {
    bar:   { key: "member_type",        label: "Users by Member Type" },
    donut: { key: "user_gender",        label: "Gender Distribution"  },
  },

  filterDropdowns: []
};
