---
name: svv02-user-master
description: "List, create, edit and delete User Master records (svv02_user_master_01). Trigger phrases: show users, list users, user master, fetch members, view user records."
version: "1.0.0"
label: "User Master"
uid: "svv02"
sql_view: "svv02_user_master_01"
tool_name: "get_svv02_user_master_01"
tags:
  - user
  - master
  - svv02
  - list-page
---

# User Master

Standard list page for `svv02_user_master_01`.

## Trigger Phrases
- show users / list users / user master
- fetch members / view user records
- svv02 user master

## Files
| File | Purpose |
|------|---------|
| `resources/index.html` | Shell HTML — identical for all skills |
| `resources/config.js`  | Columns, stats, filter, charts config |
| `resources/api.js`     | Auth chain + CRUD API calls |
| `resources/app.js`     | UI logic — identical for all skills |

## Features
- ✅ Create / Edit / Delete users
- ✅ Search by name, username, email, mobile, member ID
- ✅ Filter pills by member_type
- ✅ Stat cards: Total, Admin, Staff, Members
- ✅ Bar chart by member_type, Donut chart by gender
- ✅ CSV export

## Auth
UID: `svv02` — token fetched at runtime via `/auth/api/tbl/svv02` → `/auth/token`.
